/*
SQLyog Professional v12.09 (64 bit)
MySQL - 8.0.33 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `fwinfo` (
	`fwid` int (11),
	`fwtitle` varchar (150),
	`fwprice` int (11),
	`fwaddress` varchar (765),
	`fwtype` varchar (150),
	`fwimg` varchar (600)
); 
insert into `fwinfo` (`fwid`, `fwtitle`, `fwprice`, `fwaddress`, `fwtype`, `fwimg`) values('1001','高等数学（上）','25','全新','书籍','/img/bbb.png');
insert into `fwinfo` (`fwid`, `fwtitle`, `fwprice`, `fwaddress`, `fwtype`, `fwimg`) values('1002','2B铅笔','2','二手','文具','/img/92fcb175f41742c3afc2c3a973b7d552.png');
insert into `fwinfo` (`fwid`, `fwtitle`, `fwprice`, `fwaddress`, `fwtype`, `fwimg`) values('1003','三角板','8','全新','文具','/img/aaa.png');
insert into `fwinfo` (`fwid`, `fwtitle`, `fwprice`, `fwaddress`, `fwtype`, `fwimg`) values('1004','纯粹人身攻击','40','侯国玉著  鞍山出版社','书籍','/img/ccc.jpg');
insert into `fwinfo` (`fwid`, `fwtitle`, `fwprice`, `fwaddress`, `fwtype`, `fwimg`) values('1012','名称','12','备注','书籍','/img/QQ图片20230504221553.png');
insert into `fwinfo` (`fwid`, `fwtitle`, `fwprice`, `fwaddress`, `fwtype`, `fwimg`) values('1015','肥皂','154','gre4444','文具','/img/QQ图片20230504221553.png');
insert into `fwinfo` (`fwid`, `fwtitle`, `fwprice`, `fwaddress`, `fwtype`, `fwimg`) values('1016','说d','41','的er','电子产品','/img/90.jpg');
