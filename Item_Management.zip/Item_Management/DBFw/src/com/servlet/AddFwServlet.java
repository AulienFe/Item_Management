package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.dao.FwDao;
import com.entity.Fwinfo;

/**
 * Servlet implementation class AddFwServlet
 */
@WebServlet("/AddFwServlet")
@MultipartConfig //�����ϴ��ļ�
public class AddFwServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddFwServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		request.setCharacterEncoding("UTF-8");
		
		String fwtitle = request.getParameter("fwtitle");
		int fwprice = Integer.parseInt(request.getParameter("fwprice"));
		String fwaddress = request.getParameter("fwaddress");
		String fwtype = request.getParameter("fwtype");
		
		Part part = request.getPart("file");
		
		String path = request.getSession().getServletContext().getRealPath("/img");
		part.write(path+"\\"+part.getSubmittedFileName());
		
		FwDao dao = new FwDao();
		Fwinfo info = new Fwinfo(0,fwtitle,fwprice,fwaddress,fwtype,"/img/"+part.getSubmittedFileName());
		if(dao.AddFw(info)>0) {
			response.getWriter().append("OK");			
		}else {
			response.getWriter().append("NG");
		}
		
	}

}
