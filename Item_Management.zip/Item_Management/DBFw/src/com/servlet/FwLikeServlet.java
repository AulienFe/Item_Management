package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.FwDao;
import com.entity.Fwinfo;
import com.google.gson.Gson;

/**
 * Servlet implementation class FwLikeServlet
 */
@WebServlet("/FwLikeServlet")
public class FwLikeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FwLikeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		String fwtitle = request.getParameter("fwtitle");
		String fwaddress = request.getParameter("fwaddress");
		
		/*System.out.println(fwtite);
		System.out.println(fwaddress);*/
		
		FwDao dao = new FwDao();
		List<Fwinfo> info = dao.getFwLike(fwtitle, fwaddress);
		
		Gson gson = new Gson();
		String json = gson.toJson(info);//�Ѽ���ת����json�����ַ���
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().append(json);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
