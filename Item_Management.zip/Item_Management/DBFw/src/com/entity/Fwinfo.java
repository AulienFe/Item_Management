package com.entity;

public class Fwinfo {
	private int fwid;
	private String fwtitle;
	private int fwprice;
	private String fwaddress;
	private String fwtype;
	private String fwimg;
	
	public int getFwid() {
		return fwid;
	}
	public void setFwid(int fwid) {
		this.fwid = fwid;
	}
	public String getFwtitle() {
		return fwtitle;
	}
	public void setFwtitle(String fwtitle) {
		this.fwtitle = fwtitle;
	}
	public int getFwprice() {
		return fwprice;
	}
	public void setFwprice(int fwprice) {
		this.fwprice = fwprice;
	}
	public String getFwaddress() {
		return fwaddress;
	}
	public void setFwaddress(String fwaddress) {
		this.fwaddress = fwaddress;
	}
	public String getFwtype() {
		return fwtype;
	}
	public void setFwtype(String fwtype) {
		this.fwtype = fwtype;
	}
	public String getFwimg() {
		return fwimg;
	}
	public void setFwimg(String fwimg) {
		this.fwimg = fwimg;
	}
	public Fwinfo(int fwid, String fwtitle, int fwprice, String fwaddress, String fwtype, String fwimg) {
		super();
		this.fwid = fwid;
		this.fwtitle = fwtitle;
		this.fwprice = fwprice;
		this.fwaddress = fwaddress;
		this.fwtype = fwtype;
		this.fwimg = fwimg;
	}
	public Fwinfo() {//�Ǳ���
		super();
	}
	
	
	
}
