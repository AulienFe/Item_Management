package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao {
	BaseDao dao = new BaseDao();
	
	public boolean Login(String uname,String upwd) {//��¼��֤
		String sql = "select * from user where uname='"+uname+"' and upwd='"+upwd+"'";
		
		ResultSet rs = dao.docha(sql);
		
		try {
			if(rs.next()) {//�����ݼ�Ϊ��¼�ɹ�
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}
