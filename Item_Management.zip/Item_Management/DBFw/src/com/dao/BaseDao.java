package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BaseDao {
	Connection conn ;
	
	public void getconn() {//��ȡ����
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String password = "123456";
			String user = "root";
			String url = "jdbc:mysql://localhost:3306/dbfw";
			conn = DriverManager.getConnection(url,user,password );
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public int doexe(String sql) {//��ɾ��
		getconn();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			return pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;	
	}
	
	
	public ResultSet docha(String sql) {//��ѯ
		getconn();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			//System.out.println(pstmt.executeQuery());
			return pstmt.executeQuery();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;	
	}
	
}
