package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.entity.*;
//import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;
//import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;
import java.util.List;

public class FwDao {
	BaseDao dao = new BaseDao();
	
	public List<Fwinfo> getFwAll(){
		String sql = "select * from fwinfo";
		
		List<Fwinfo> infolist = new ArrayList<>();
		ResultSet rs = dao.docha(sql);
		try {
			while(rs.next()) {
				Fwinfo info = new Fwinfo(
						rs.getInt("fwid"),
						rs.getString("fwtitle"),
						rs.getInt("fwprice"),
						rs.getString("fwaddress"),
						rs.getString("fwtype"),
						rs.getString("fwimg")
						);
				
				infolist.add(info);
			}
			return infolist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public int DelFw(int fwid) {//ɾ��
		String sql = "delete from fwinfo where fwid="+fwid;
		return dao.doexe(sql);
		
	}
	
	public List<Fwinfo> getFwLike(String fwtitle,String fwaddress){//����
		String sql = "select * from fwinfo where 1=1";
		if(fwtitle!="" && fwaddress=="") {
			sql+=" and fwtitle like '%"+fwtitle+"%'";
		}else if(fwtitle=="" && fwaddress!="") {
			sql+=" and fwaddress like '%"+fwaddress+"%'";
		}else if(fwtitle!="" && fwaddress!="") {
			sql+=" and fwaddress like '%"+fwaddress+"%' and fwtitle like '%"+fwtitle+"%'";
		}
		
		List<Fwinfo> infolist = new ArrayList<>();
		ResultSet rs = dao.docha(sql);
		try {
			while(rs.next()) {
				Fwinfo info = new Fwinfo(
						rs.getInt("fwid"),
						rs.getString("fwtitle"),
						rs.getInt("fwprice"),
						rs.getString("fwaddress"),
						rs.getString("fwtype"),
						rs.getString("fwimg")
						);
				
				infolist.add(info);
			}
			return infolist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
		
	}
	
	public Fwinfo getFw(int fwid) {
		
		String sql = "select * from fwinfo where fwid="+fwid;
		//System.out.println(sql);
		ResultSet rs = dao.docha(sql);
		
		//System.out.println(rs.getInt("fwid"));		
		try {
			/*Fwinfo info = new Fwinfo(
					rs.getInt("fwid"),
					rs.getString("fwtitle"),
					rs.getInt("fwprice"),
					rs.getString("fwaddress"),
					rs.getString("fwtype"),
					rs.getString("fwimg")
					);*/
							
			Fwinfo info = new Fwinfo();
			while(rs.next()) {
				info.setFwid(rs.getInt("fwid"));
				info.setFwtitle(rs.getString("fwtitle"));
				info.setFwprice(rs.getInt("fwprice"));
				info.setFwaddress(rs.getString("fwaddress"));
				info.setFwtype(rs.getString("fwtype"));
				info.setFwimg(rs.getString("fwimg"));System.out.println(info);
				
			}
			return info;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	
	public int AddFw(Fwinfo info) {
		
		String sql ="insert into fwinfo values (null,'"+info.getFwtitle()+"',"+info.getFwprice()+",'"+info.getFwaddress()+"','"+info.getFwtype()+"','"+info.getFwimg()+"')";
		return dao.doexe(sql);
		
	}
	
	public int AlterFw(Fwinfo info) {
		
		//String sql ="insert into fwinfo values (null,'"+info.getFwtitle()+"',"+info.getFwprice()+",'"+info.getFwaddress()+"','"+info.getFwtype()+"','"+info.getFwimg()+"')";
		String sql = "UPDATE fwinfo SET fwtitle='"+info.getFwtitle()+"',fwprice="+info.getFwprice()+",fwaddress='"+info.getFwaddress()+"',fwtype='"+info.getFwtype()+"',fwimg='"+info.getFwimg()+"' WHERE fwid="+info.getFwid();
		System.out.println(sql);
		return dao.doexe(sql);
		
	}
	
	public int AlterFw1(Fwinfo info) {
		
		//String sql ="insert into fwinfo values (null,'"+info.getFwtitle()+"',"+info.getFwprice()+",'"+info.getFwaddress()+"','"+info.getFwtype()+"','"+info.getFwimg()+"')";
		String sql = "UPDATE fwinfo SET fwtitle='"+info.getFwtitle()+"',fwprice="+info.getFwprice()+",fwaddress='"+info.getFwaddress()+"',fwtype='"+info.getFwtype()+"' WHERE fwid="+info.getFwid();
		//System.out.println(sql);
		return dao.doexe(sql);
		
	}
	

}
