/*
SQLyog Professional v12.09 (64 bit)
MySQL - 8.0.33 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `user` (
	`uname` varchar (60),
	`upwd` varchar (60)
); 
insert into `user` (`uname`, `upwd`) values('admin','123456');
insert into `user` (`uname`, `upwd`) values('user1','123');
insert into `user` (`uname`, `upwd`) values('user2','321');
